#!/bin/bash
#
# F.Vannini 2006 (vannini@cli.di.unipi.it)
#

if [ ! -x "/usr/bin/dpkg-deb" ]; then
	echo "This script is for debian systems only!"
	exit 1
fi

cd "$(dirname $0)"

if [ ! -d "debroot" ]; then
	echo "debroot directory not found!"
	exit 1
fi

if [ ! -f "DEBIAN_control" ]; then
	echo "DEBIAN_control file not found!"
	exit 1
fi

VERSION=$(grep -i "version:" DEBIAN_control | cut -f2 -d" ")
PKGNAME=$(grep -i "package:" DEBIAN_control | cut -f2 -d" ")
mkdir -p debroot/DEBIAN
cp DEBIAN_control debroot/DEBIAN/control

for i in $(find debroot/ -path 'debroot/DEBIAN' -prune -o -type f -print); do 
	md5sum "$i"; 
done | sed 's/debroot\///' >  ./debroot/DEBIAN/md5sums
dpkg-deb -b debroot/ $PKGNAME"_"$VERSION".deb"
