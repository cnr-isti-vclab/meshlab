Lo script debgen.sh genera un pacchetto debian seguendo le informazioni 
contenute nel file DEBIAN_control. E' importante che il formato del file 
rimanga inalterato; il primo rigo del campo "Description" deve contenere una 
descrizione breve (circa 100 bytes) seguita nelle righe successive da una
descrizione completa del software contenuto nel pacchetto; è buona norma
che tale descrizione sia wrappata a circa 75 bytes e che ciascun rigo inizi
con uno spazio. Il significato dei campi restanti è intuitivo e non ci sono
particolari regole di formattazione da seguire (basta seguire l'esempio).

Per generare il pacchetto:

1)	creare la directory debroot

2) 	copiare tutti i files da installare nella directory debroot ricreandovi 
	le sottodirectory così come dovranno essere nel sistema una volta 
	installato il pacchetto. La directory debroot corrisponde alla directory
	/ del sistema (ad es. debroot/usr/bin/meshlab sarà /usr/bin/meshlab sul 
	sistema una volta installato il pacchetto). 
	
3)	modificare il file DEBIAN_control (che ci si aspetta essere nella stessa
	directory dello script) a piacimento
	
4) 	lanciare lo script

Se lo script arriva in fondo senza problemi verrà creato un file .deb chiamato
nomepacchetto_versione.deb in base al contenuto dei campi del file 
DEBIAN_control.
